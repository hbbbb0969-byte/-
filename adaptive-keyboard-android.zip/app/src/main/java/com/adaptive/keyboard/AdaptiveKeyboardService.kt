package com.adaptive.keyboard

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * خدمة لوحة المفاتيح الحقيقية (IME) — تعمل داخل كل تطبيقات الهاتف.
 * عند فتح أي تطبيق تقرأ الخدمة اسم حزمة التطبيق وتستخرج ألوانه تلقائياً
 * وتعيد رسم لوحة المفاتيح بنفس الهوية اللونية، بدون إنترنت.
 */
class AdaptiveKeyboardService : InputMethodService() {

    private lateinit var root: LinearLayout
    private lateinit var statusView: TextView
    private lateinit var keysContainer: LinearLayout

    private var theme: AppTheme = AppTheme.DEFAULT
    private var arabic = true
    private var numbers = false
    private var shift = false

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(6), dp(4), dp(10))
        }

        statusView = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(6))
        }
        root.addView(statusView)

        keysContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(keysContainer)

        render()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        // التكيّف التلقائي مع التطبيق المفتوح حالياً
        theme = ThemeExtractor.themeFor(this, info?.packageName)
        render()
    }

    private fun render() {
        root.setBackgroundColor(theme.background)
        statusView.setTextColor(theme.keyText)
        statusView.text = "مظهر مطابق لـ ${theme.label}"

        keysContainer.removeAllViews()

        val rows = when {
            numbers -> KeyboardLayouts.NUMBERS
            arabic -> KeyboardLayouts.ARABIC
            else -> KeyboardLayouts.ENGLISH
        }

        rows.forEach { row ->
            val rowView = newRow()
            row.forEach { key ->
                rowView.addView(
                    keyButton(if (!arabic && shift) key.uppercase() else key, 1f) {
                        commit(if (!arabic && shift) key.uppercase() else key)
                    }
                )
            }
            keysContainer.addView(rowView)
        }

        val bottom = newRow()
        if (!arabic && !numbers) {
            bottom.addView(keyButton(if (shift) "⇧" else "⇪", 1.3f, accent = shift) {
                shift = !shift
                render()
            })
        }
        bottom.addView(keyButton(if (numbers) "أ ب" else "١٢٣", 1.4f) {
            numbers = !numbers
            render()
        })
        // زر تبديل اللغة (عربي / إنجليزي)
        bottom.addView(keyButton("🌐", 1.2f) {
            arabic = !arabic
            numbers = false
            render()
        })
        bottom.addView(keyButton(if (arabic) "العربية" else "English", 3.4f) { commit(" ") })
        bottom.addView(keyButton("⌫", 1.4f, accent = true) {
            currentInputConnection?.deleteSurroundingText(1, 0)
        })
        bottom.addView(keyButton("↵", 1.4f, accent = true) {
            currentInputConnection?.performEditorAction(EditorInfo.IME_ACTION_GO)
        })
        keysContainer.addView(bottom)
    }

    private fun commit(text: String) {
        currentInputConnection?.commitText(text, 1)
    }

    private fun newRow() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(3) }
    }

    private fun keyButton(
        label: String,
        weight: Float,
        accent: Boolean = false,
        onClick: () -> Unit,
    ): Button {
        val bg = if (accent) theme.accent else theme.keyBackground
        val fg = if (accent) theme.accentText else theme.keyText
        return Button(this).apply {
            text = label
            isAllCaps = false
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(fg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setPadding(0, 0, 0, 0)
            stateListAnimator = null
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(bg)
                setStroke(1, Color.argb(40, 255, 255, 255))
            }
            layoutParams = LinearLayout.LayoutParams(0, dp(46), weight).apply {
                marginStart = dp(2)
                marginEnd = dp(2)
            }
            setOnClickListener { onClick() }
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}