package com.adaptive.keyboard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.palette.graphics.Palette

/**
 * يقرأ أيقونة التطبيق المفتوح ويستخرج منها لوحة ألوان — يعمل بالكامل بدون إنترنت.
 * النتائج تُخزَّن في الذاكرة حتى تكون الاستجابة فورية.
 */
object ThemeExtractor {

    private val cache = HashMap<String, AppTheme>()

    fun themeFor(context: Context, packageName: String?): AppTheme {
        if (packageName.isNullOrBlank()) return AppTheme.DEFAULT
        cache[packageName]?.let { return it }

        val theme = try {
            val pm = context.packageManager
            val icon = pm.getApplicationIcon(packageName)
            val label = pm.getApplicationLabel(pm.getApplicationInfo(packageName, 0)).toString()
            build(toBitmap(icon), label)
        } catch (e: Exception) {
            AppTheme.DEFAULT
        }

        cache[packageName] = theme
        return theme
    }

    private fun toBitmap(drawable: Drawable): Bitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) return drawable.bitmap
        val w = drawable.intrinsicWidth.coerceAtLeast(1)
        val h = drawable.intrinsicHeight.coerceAtLeast(1)
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }

    private fun build(bitmap: Bitmap, label: String): AppTheme {
        val palette = Palette.from(bitmap).clearFilters().generate()
        val accent = palette.getVibrantColor(
            palette.getDominantColor(AppTheme.DEFAULT.accent)
        )
        val dark = isDark(accent)

        val background = shade(accent, if (dark) 0.35f else 0.18f)
        val keyBackground = shade(accent, if (dark) 0.55f else 0.30f)
        val keyText = if (isDark(keyBackground)) Color.WHITE else Color.parseColor("#101010")

        return AppTheme(
            background = background,
            keyBackground = keyBackground,
            keyText = keyText,
            accent = accent,
            accentText = if (isDark(accent)) Color.WHITE else Color.parseColor("#101010"),
            label = label,
        )
    }

    /** يمزج اللون مع الأسود بنسبة معيّنة للحصول على خلفية متناسقة. */
    private fun shade(color: Int, factor: Float): Int {
        val r = (Color.red(color) * factor).toInt().coerceIn(0, 255)
        val g = (Color.green(color) * factor).toInt().coerceIn(0, 255)
        val b = (Color.blue(color) * factor).toInt().coerceIn(0, 255)
        return Color.rgb(r, g, b)
    }

    private fun isDark(color: Int): Boolean {
        val luminance =
            (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255
        return luminance < 0.55
    }
}