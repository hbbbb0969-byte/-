package com.adaptive.keyboard

import android.graphics.Color

/** ألوان لوحة المفاتيح المشتقة تلقائياً من التطبيق المفتوح. */
data class AppTheme(
    val background: Int,
    val keyBackground: Int,
    val keyText: Int,
    val accent: Int,
    val accentText: Int,
    val label: String,
) {
    companion object {
        val DEFAULT = AppTheme(
            background = Color.parseColor("#1C1C1E"),
            keyBackground = Color.parseColor("#3A3A3C"),
            keyText = Color.parseColor("#F2F2F7"),
            accent = Color.parseColor("#4C5A3F"),
            accentText = Color.WHITE,
            label = "افتراضي",
        )
    }
}